# eHRIS – Vue Frontend

Frontend-only Vue 3 app for the Human Resource Information System. Uses mock data aligned with `ehris_db_clean.sql`. Ready to connect to a Laravel API later.

## Run locally

```bash
npm install
npm run dev
```

Open http://localhost:5173

## Features

- **Vue 3** + Vite + Vue Router
- **Layout**: Sidebar + header, responsive-ready
- **Employees**: DataTable with lazy-loading (paginated, one page at a time), search, page size 10/25/50/100
- **Dashboard**: Placeholder stats and quick links
- **Departments / Leave**: Placeholder pages (replace with API later)

## Database alignment

Mock data follows:

- `tbl_emp_official_info` / `tbl_user`: employee list (hrid, firstname, lastname, job_title, department_id, etc.)
- `tbl_department`: department list

Replace `src/data/mockEmployees.js` and use Laravel API endpoints for:

- `fetchEmployeePage({ page, pageSize, search })` → e.g. `GET /api/employees?page=1&per_page=10&search=...`
- Departments and leave when you add Laravel backend

## Build

```bash
npm run build
```

Output is in `dist/`.
