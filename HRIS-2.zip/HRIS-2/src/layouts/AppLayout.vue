<template>
  <div class="app-layout">
    <!-- Orange header -->
    <header class="top-header">
      <div class="header-left">
        <button type="button" class="hamburger" aria-label="Menu">☰</button>
        <div class="logo">
          <span class="logo-deped">DepED</span>
          <span class="logo-zamiz"> Ozamiz</span>
        </div>
      </div>
      <div class="header-right">
        <div class="notif-wrap">
          <span class="notif-icon">🔔</span>
          <span class="notif-badge">1</span>
        </div>
        <div class="header-user">
          <div class="header-avatar">G</div>
          <span class="header-user-name">Gavino O. Tan</span>
          <span class="header-chevron">▼</span>
        </div>
      </div>
    </header>

    <div class="body-wrap">
      <!-- Dark grey sidebar -->
      <aside class="sidebar">
        <div class="sidebar-user">
          <div class="sidebar-avatar">G</div>
          <div class="sidebar-user-name">Gavino O. Tan</div>
          <div class="sidebar-user-email">gavino.tan@deped.gov.ph</div>
        </div>
        <div class="sidebar-search">
          <span class="search-icon">🔍</span>
          <input type="text" placeholder="Search..." class="sidebar-search-input" />
        </div>
        <div class="nav-label">MAIN NAVIGATION</div>
        <nav class="sidebar-nav">
          <router-link to="/dashboard" class="nav-item" active-class="active">
            <span class="nav-icon">▣</span>
            <span class="nav-text">Dashboard</span>
            <span class="nav-chevron">›</span>
          </router-link>
          <router-link to="/cot-rpms" class="nav-item" active-class="active">
            <span class="nav-icon">📈</span>
            <span class="nav-text">COT-RPMS Summary</span>
            <span class="nav-chevron">›</span>
          </router-link>
          <router-link to="/sat-summary" class="nav-item" active-class="active">
            <span class="nav-icon">📈</span>
            <span class="nav-text">SAT-Summary</span>
            <span class="nav-chevron">›</span>
          </router-link>
          <router-link to="/employees" class="nav-item" active-class="active">
            <span class="nav-icon">👥</span>
            <span class="nav-text">Employee Management</span>
            <span class="nav-chevron">›</span>
          </router-link>
          <router-link to="/self-service" class="nav-item" active-class="active">
            <span class="nav-icon">✎</span>
            <span class="nav-text">Self-Service</span>
            <span class="nav-chevron">›</span>
          </router-link>
          <router-link to="/request-status" class="nav-item" active-class="active">
            <span class="nav-icon">📄</span>
            <span class="nav-text">Request Status</span>
            <span class="nav-chevron">›</span>
          </router-link>
          <router-link to="/my-details" class="nav-item" active-class="active">
            <span class="nav-icon">📄</span>
            <span class="nav-text">My Details</span>
            <span class="nav-chevron">›</span>
          </router-link>
          <router-link to="/utilities" class="nav-item" active-class="active">
            <span class="nav-icon">⚙</span>
            <span class="nav-text">Utilities</span>
            <span class="nav-chevron">›</span>
          </router-link>
          <router-link to="/survey" class="nav-item" active-class="active">
            <span class="nav-icon">⚙</span>
            <span class="nav-text">Survey</span>
            <span class="nav-chevron">›</span>
          </router-link>
        </nav>
      </aside>

      <!-- Main content -->
      <div class="main-wrap">
        <main class="main">
          <router-view v-slot="{ Component }">
            <transition name="fade" mode="out-in">
              <component :is="Component" />
            </transition>
          </router-view>
        </main>
      </div>
    </div>
  </div>
</template>

<script setup>
</script>

<style scoped>
.app-layout {
  min-height: 100vh;
  display: flex;
  flex-direction: column;
}

.top-header {
  height: 56px;
  background: var(--header-orange);
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 1rem;
  flex-shrink: 0;
}

.header-left {
  display: flex;
  align-items: center;
  gap: 0.75rem;
}

.hamburger {
  background: none;
  border: none;
  color: #fff;
  font-size: 1.25rem;
  padding: 0.25rem 0.5rem;
  cursor: pointer;
}

.logo {
  font-size: 1.25rem;
  font-weight: 700;
  color: #fff;
}

.logo-deped {
  color: #fff;
  letter-spacing: 0.02em;
}

.logo-zamiz {
  font-weight: 600;
  opacity: 0.95;
}

.header-right {
  display: flex;
  align-items: center;
  gap: 1rem;
}

.notif-wrap {
  position: relative;
}

.notif-icon {
  font-size: 1.25rem;
  display: block;
  color: #fff;
}

.notif-badge {
  position: absolute;
  top: -4px;
  right: -4px;
  min-width: 16px;
  height: 16px;
  background: #c0392b;
  color: #fff;
  font-size: 0.7rem;
  font-weight: 700;
  border-radius: 8px;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 0 4px;
}

.header-user {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  color: #fff;
  cursor: pointer;
}

.header-avatar {
  width: 36px;
  height: 36px;
  border-radius: 50%;
  background: rgba(255, 255, 255, 0.25);
  color: #fff;
  display: flex;
  align-items: center;
  justify-content: center;
  font-weight: 700;
  font-size: 0.9rem;
}

.header-user-name {
  font-size: 0.9rem;
  font-weight: 500;
}

.header-chevron {
  font-size: 0.6rem;
  opacity: 0.9;
}

.body-wrap {
  flex: 1;
  display: flex;
  min-height: 0;
}

.sidebar {
  width: 260px;
  background: var(--sidebar-bg);
  color: var(--sidebar-text);
  display: flex;
  flex-direction: column;
  flex-shrink: 0;
  overflow-y: auto;
}

.sidebar-user {
  padding: 1.25rem 1rem;
  border-bottom: 1px solid rgba(255, 255, 255, 0.08);
}

.sidebar-avatar {
  width: 64px;
  height: 64px;
  border-radius: 50%;
  background: rgba(255, 255, 255, 0.15);
  color: #fff;
  display: flex;
  align-items: center;
  justify-content: center;
  font-weight: 700;
  font-size: 1.5rem;
  margin-bottom: 0.5rem;
}

.sidebar-user-name {
  font-weight: 600;
  color: var(--sidebar-active);
  font-size: 0.95rem;
}

.sidebar-user-email {
  font-size: 0.8rem;
  color: var(--sidebar-text);
  margin-top: 0.25rem;
}

.sidebar-search {
  padding: 0.75rem 1rem;
  display: flex;
  align-items: center;
  gap: 0.5rem;
  background: rgba(0, 0, 0, 0.15);
  margin: 0 0.75rem;
  border-radius: 6px;
}

.search-icon {
  font-size: 0.9rem;
  opacity: 0.7;
}

.sidebar-search-input {
  flex: 1;
  background: none;
  border: none;
  color: #fff;
  font-size: 0.875rem;
  outline: none;
}

.sidebar-search-input::placeholder {
  color: rgba(255, 255, 255, 0.6);
}

.nav-label {
  padding: 0.75rem 1rem 0.5rem;
  font-size: 0.7rem;
  font-weight: 700;
  letter-spacing: 0.08em;
  color: var(--sidebar-text);
  opacity: 0.8;
}

.sidebar-nav {
  flex: 1;
  padding: 0 0.5rem 1rem;
  display: flex;
  flex-direction: column;
  gap: 2px;
}

.nav-item {
  display: flex;
  align-items: center;
  gap: 0.6rem;
  padding: 0.65rem 0.75rem;
  border-radius: 6px;
  color: var(--sidebar-text);
  font-size: 0.9rem;
  transition: background 0.2s, color 0.2s;
}

.nav-item:hover {
  background: var(--sidebar-active-bg);
  color: var(--sidebar-active);
}

.nav-item.active {
  background: var(--sidebar-active-bg);
  color: var(--sidebar-active);
  font-weight: 500;
}

.nav-icon {
  font-size: 1rem;
  opacity: 0.9;
  width: 1.25rem;
  text-align: center;
}

.nav-text {
  flex: 1;
}

.nav-chevron {
  font-size: 1rem;
  opacity: 0.7;
}

.main-wrap {
  flex: 1;
  background: var(--body-bg);
  overflow: auto;
}

.main {
  padding: 1.25rem 1.5rem;
  max-width: 1400px;
  margin: 0 auto;
}

.fade-enter-active,
.fade-leave-active {
  transition: opacity 0.15s ease;
}
.fade-enter-from,
.fade-leave-to {
  opacity: 0;
}
</style>
