<template>
  <div class="my-details">
    <!-- Breadcrumbs top right -->
    <div class="breadcrumbs">
      <router-link to="/dashboard">Home</router-link>
      <span class="bread-sep">></span>
      <span>My Details</span>
    </div>

    <h1 class="page-title">My Details</h1>

    <!-- Employee Basic Details Card -->
    <div class="basic-details-card">
      <div class="basic-details-photo">
        <div class="photo-placeholder">G</div>
      </div>
      <div class="basic-details-fields">
        <div class="detail-row">
          <span class="detail-label">Employee Name:</span>
          <span class="detail-value detail-name">{{ employee.employeeName }}</span>
        </div>
        <div class="detail-row">
          <span class="detail-label">HR ID:</span>
          <span class="detail-value">{{ employee.hrId }}</span>
        </div>
        <div class="detail-row">
          <span class="detail-label">Employee No:</span>
          <span class="detail-value">{{ employee.employeeNo }}</span>
        </div>
        <div class="detail-row">
          <span class="detail-label">Email:</span>
          <a :href="`mailto:${employee.email}`" class="detail-value detail-email">{{ employee.email }}</a>
        </div>
        <div class="detail-row">
          <span class="detail-label">Contact No:</span>
          <span class="detail-value">{{ employee.contactNo }}</span>
        </div>
      </div>
    </div>

    <!-- Primary tabs -->
    <div class="tabs-primary">
      <button
        v-for="tab in primaryTabs"
        :key="tab.key"
        type="button"
        class="tab-primary"
        :class="{ active: activePrimary === tab.key }"
        @click="activePrimary = tab.key"
      >
        {{ tab.label }}
      </button>
    </div>

    <!-- Secondary tabs (for Education) -->
    <div v-if="activePrimary === 'education'" class="tabs-secondary">
      <button
        v-for="tab in secondaryTabs"
        :key="tab.key"
        type="button"
        class="tab-secondary"
        :class="{ active: activeSecondary === tab.key }"
        @click="activeSecondary = tab.key"
      >
        {{ tab.label }}
      </button>
    </div>

    <!-- Education content (table with Add Education - shown when primary is EDUCATION) -->
    <div v-if="activePrimary === 'education'" class="tab-content">
      <div class="content-toolbar">
        <span class="toolbar-spacer"></span>
        <button type="button" class="btn-add-education" @click="onAddEducation">+ Add Education</button>
      </div>
      <div class="education-table-wrap">
        <table class="education-table">
          <thead>
            <tr>
              <th>Action</th>
              <th>Educational Level</th>
              <th>School Name</th>
              <th>Course</th>
              <th>Highest Grade</th>
              <th>From Year</th>
              <th>To Year</th>
              <th>Year Graduated</th>
              <th>Scholarship/Academic</th>
            </tr>
          </thead>
          <tbody>
            <tr v-if="educationRows.length === 0">
              <td colspan="9" class="no-data">No data available in table</td>
            </tr>
            <tr v-else v-for="(row, i) in educationRows" :key="i">
              <td>
                <button type="button" class="btn-action" @click="editEducation(row)">Edit</button>
              </td>
              <td>{{ row.educationalLevel }}</td>
              <td>{{ row.schoolName }}</td>
              <td>{{ row.course }}</td>
              <td>{{ row.highestGrade }}</td>
              <td>{{ row.fromYear }}</td>
              <td>{{ row.toYear }}</td>
              <td>{{ row.yearGraduated }}</td>
              <td>{{ row.scholarship }}</td>
            </tr>
          </tbody>
        </table>
      </div>
      <div class="table-footer">
        <span class="footer-info">Showing {{ startEntry }} to {{ endEntry }} of {{ totalEntries }} entries</span>
        <div class="footer-pagination">
          <button type="button" class="footer-btn" :disabled="true">Previous</button>
          <button type="button" class="footer-btn" :disabled="true">Next</button>
        </div>
      </div>
    </div>

    <!-- Placeholder content for other primary tabs -->
    <div v-else class="tab-content tab-content-placeholder">
      <p class="placeholder-text">{{ activePrimary }} content will be loaded here.</p>
    </div>
  </div>
</template>

<script setup>
import { ref, computed } from 'vue'

const employee = ref({
  employeeName: 'GAVINO ONG TAN',
  hrId: '20856',
  employeeNo: '14344',
  email: 'gavino.tan@deped.gov.ph',
  contactNo: '0912345678',
})

const primaryTabs = [
  { key: 'official', label: 'OFFICIAL INFO' },
  { key: 'personal', label: 'PERSONAL INFO' },
  { key: 'contact', label: 'CONTACT INFO' },
  { key: 'family', label: 'FAMILY' },
  { key: 'education', label: 'EDUCATION' },
  { key: 'work', label: 'WORK EXPERIENCE' },
  { key: 'eligibility', label: 'ELIGIBILITY' },
  { key: 'service', label: 'SERVICE RECORD' },
  { key: 'leave', label: 'LEAVE HISTORY' },
  { key: 'documents', label: 'DOCUMENTS' },
]

const secondaryTabs = [
  { key: 'training', label: 'TRAINING' },
  { key: 'awards', label: 'AWARDS' },
  { key: 'performance', label: 'PERFORMANCE' },
  { key: 'researches', label: 'RESEARCHES' },
  { key: 'expertise', label: 'EXPERTISE' },
  { key: 'affiliation', label: 'AFFILIATION' },
]

const activePrimary = ref('education')
const activeSecondary = ref('training')

const educationRows = ref([]) // empty = "No data available in table"
const totalEntries = computed(() => educationRows.value.length)
const startEntry = computed(() => totalEntries.value === 0 ? 0 : 1)
const endEntry = computed(() => totalEntries.value)

function onAddEducation() {
  alert('Add Education form will open here. Connect to Laravel API later.')
}

function editEducation(row) {
  alert('Edit education: ' + row.schoolName)
}
</script>

<style scoped>
.my-details {
  background: #fff;
  border-radius: 8px;
  padding: 1.5rem;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.08);
}

.breadcrumbs {
  display: flex;
  align-items: center;
  justify-content: flex-end;
  gap: 0.35rem;
  font-size: 0.875rem;
  color: var(--text-muted);
  margin-bottom: 0.5rem;
}

.breadcrumbs a {
  color: var(--link-blue);
  text-decoration: none;
}

.breadcrumbs a:hover {
  text-decoration: underline;
}

.bread-sep {
  margin: 0 0.2rem;
}

.page-title {
  font-size: 1.5rem;
  font-weight: 700;
  color: var(--text-primary);
  margin-bottom: 1.25rem;
}

/* Basic details card */
.basic-details-card {
  display: flex;
  gap: 2rem;
  padding: 1.5rem;
  background: var(--table-header);
  border: 1px solid var(--table-border);
  border-radius: 8px;
  margin-bottom: 1.5rem;
}

.basic-details-photo {
  flex-shrink: 0;
}

.photo-placeholder {
  width: 140px;
  height: 140px;
  border-radius: 8px;
  background: var(--sidebar-bg);
  color: rgba(255, 255, 255, 0.8);
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 3rem;
  font-weight: 700;
}

.basic-details-fields {
  display: flex;
  flex-direction: column;
  gap: 0.75rem;
  justify-content: center;
}

.detail-row {
  display: flex;
  align-items: baseline;
  gap: 0.5rem;
}

.detail-label {
  font-weight: 700;
  font-size: 0.9rem;
  color: var(--text-primary);
  min-width: 130px;
}

.detail-value {
  font-size: 0.9rem;
  color: var(--text-primary);
}

.detail-name {
  text-transform: uppercase;
  letter-spacing: 0.02em;
}

.detail-email {
  color: var(--link-blue);
  text-decoration: none;
}

.detail-email:hover {
  text-decoration: underline;
}

/* Primary tabs */
.tabs-primary {
  display: flex;
  flex-wrap: wrap;
  gap: 0;
  border-bottom: 2px solid var(--table-border);
  margin-bottom: 0;
}

.tab-primary {
  padding: 0.6rem 1rem;
  font-size: 0.8rem;
  font-weight: 600;
  letter-spacing: 0.02em;
  color: var(--text-muted);
  background: none;
  border: none;
  border-bottom: 3px solid transparent;
  margin-bottom: -2px;
  cursor: pointer;
}

.tab-primary:hover {
  color: var(--text-primary);
}

.tab-primary.active {
  color: var(--text-primary);
  border-bottom-color: var(--text-primary);
}

/* Secondary tabs */
.tabs-secondary {
  display: flex;
  flex-wrap: wrap;
  gap: 0;
  border-bottom: 1px solid var(--table-border);
  margin-bottom: 1rem;
  padding-bottom: 0;
}

.tab-secondary {
  padding: 0.5rem 0.75rem;
  font-size: 0.75rem;
  font-weight: 600;
  letter-spacing: 0.02em;
  color: var(--text-muted);
  background: none;
  border: none;
  border-bottom: 2px solid transparent;
  margin-bottom: -1px;
  cursor: pointer;
}

.tab-secondary:hover {
  color: var(--text-primary);
}

.tab-secondary.active {
  color: var(--text-primary);
  border-bottom-color: var(--text-primary);
}

/* Tab content */
.tab-content {
  padding-top: 1rem;
}

.content-toolbar {
  display: flex;
  align-items: center;
  justify-content: flex-end;
  margin-bottom: 0.75rem;
}

.toolbar-spacer {
  flex: 1;
}

.btn-add-education {
  padding: 0.5rem 1rem;
  font-size: 0.875rem;
  font-weight: 600;
  color: #fff;
  background: var(--btn-pink);
  border: none;
  border-radius: 6px;
  cursor: pointer;
}

.btn-add-education:hover {
  background: var(--btn-pink-hover);
}

.education-table-wrap {
  overflow-x: auto;
  border: 1px solid var(--table-border);
  border-radius: 6px;
}

.education-table {
  width: 100%;
  border-collapse: collapse;
  font-size: 0.875rem;
}

.education-table th {
  text-align: left;
  padding: 0.6rem 0.75rem;
  background: var(--table-header);
  font-weight: 600;
  color: var(--text-primary);
  border-bottom: 1px solid var(--table-border);
  white-space: nowrap;
}

.education-table td {
  padding: 0.6rem 0.75rem;
  border-bottom: 1px solid var(--table-border);
  color: var(--text-primary);
}

.education-table tbody tr:hover {
  background: var(--table-hover);
}

.no-data {
  text-align: center;
  padding: 2rem !important;
  color: var(--text-muted);
  font-size: 0.9rem;
}

.btn-action {
  padding: 0.25rem 0.5rem;
  font-size: 0.8rem;
  background: var(--accent);
  color: #fff;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

.btn-action:hover {
  background: var(--accent-hover);
}

.table-footer {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0.75rem 0.5rem 0;
  font-size: 0.8125rem;
  color: var(--text-muted);
  flex-wrap: wrap;
  gap: 0.5rem;
}

.footer-pagination {
  display: flex;
  gap: 0.35rem;
}

.footer-btn {
  padding: 0.35rem 0.65rem;
  border: 1px solid var(--table-border);
  background: #fff;
  border-radius: 4px;
  font-size: 0.8125rem;
  color: var(--text-primary);
  cursor: pointer;
}

.footer-btn:disabled {
  opacity: 0.6;
  cursor: not-allowed;
}

.tab-content-placeholder {
  padding: 2rem;
  text-align: center;
  color: var(--text-muted);
}

.placeholder-text {
  font-size: 0.9375rem;
}
</style>
